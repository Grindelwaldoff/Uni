double formula(int iteration_max);
