#include <stdio.h>
#include <stdlib.h>

int GetInt(void);
